# HomeDash – Website Prompt for Hostinger Horizons

This file is **not** the project README. It is a ready-to-paste prompt for [Hostinger Horizons](https://www.hostinger.com/horizons) that builds the **marketing / landing website for HomeDash**.

## How to use

1. Open Hostinger Horizons and start a new project.
2. Copy everything inside the **big prompt block** below (from `Build a modern…` to the end of the block) and paste it into the chat.
3. When Horizons has generated the first version, upload the screenshots from `docs/` (`dashboard.png`, `terminal.png`, `theme-dracula.png`) and send the **follow-up prompts** at the bottom to refine the site.
4. Replace `YOUR_USER` in the GitHub links with your real GitHub username before publishing.

---

## The prompt

```text
Build a modern, fast, fully responsive one-page marketing website (with a few extra sub-pages) for an open-source software project called "HomeDash".

=== WHAT HOMEDASH IS ===
HomeDash is a free, open-source, self-hosted dashboard for self-hosters, homelabs, VPS and servers. It is a live control panel for the machine it runs on: it shows hardware stats and temperatures, lists and controls Docker containers and Docker Compose projects, shows a grid of links with logos, integrates with Home Assistant, offers a web terminal, and has user accounts with an admin panel. It is a single small Python program with NO dependencies (no pip, no npm, no database) plus a plain JavaScript frontend. License: MIT. Languages: English, German, Spanish, French.

Tagline: "The all-in-one dashboard for your homelab."
Sub-tagline: "Hardware stats, Docker, Compose, Home Assistant and a web terminal – in one lightweight, self-hosted dashboard."

=== DESIGN ===
- Style: dark, modern developer-tool look (think Linear / Vercel / Tailscale). Clean, lots of whitespace, rounded cards (14px radius), subtle glass effect, soft glow behind the hero.
- Colors: background #0f1117, card background rgba(255,255,255,0.05) with 1px border rgba(255,255,255,0.09), text #e8eaf0, muted text #8b92a5, primary accent indigo #6366f1, success green #34d399, warning amber #fbbf24.
- Fonts: Inter (or system sans) for text, a monospace font (JetBrains Mono or system mono) for code.
- Use a simple house icon "⌂" in a rounded indigo square as the logo.
- Smooth, subtle scroll-reveal animations. No heavy animations. Excellent mobile layout (single column, sticky compact header).
- Include a dark/light theme toggle (dark is default).
- Include a language switcher (EN / DE / ES / FR) in the header. At minimum translate the navigation, hero, feature titles and the call-to-action buttons into all four languages.

=== PAGE STRUCTURE (one page with anchor navigation) ===
Sticky header: logo + "HomeDash", links: Features, Screenshots, Install, Home Assistant, Security, FAQ; right side: language switcher, theme toggle, "GitHub" button (outline) and "Get started" button (indigo, filled).

1. HERO
   - Big headline: "Your homelab. One dashboard."
   - Sub-headline: the sub-tagline above.
   - Two buttons: "Get started" (scrolls to Install) and "Star on GitHub" (https://github.com/YOUR_USER/homedash).
   - Small badges row: MIT License · Zero dependencies · Docker ready · EN / DE / ES / FR.
   - Below: a large screenshot of the dashboard inside a browser-window frame with a soft indigo glow. Use the uploaded image "dashboard.png". If no image is available yet, build a nice CSS mock of the dashboard (cards with CPU ring, memory bars, container list).
   - A one-line install command in a copyable code box: ./install.sh

2. TRUST STRIP
   Four short stats in a row: "0 dependencies", "1 small Python file backend", "4 languages", "7 themes".

3. FEATURES (grid of 12 cards, each with an emoji/icon, title and 1–2 lines)
   - 🖥 Hardware & system – CPU model, cores, live usage per core, load, RAM, swap, disks, NVIDIA GPU, network graphs, uptime.
   - 🌡 Temperatures – every sensor from hwmon and thermal zones plus GPU, with warning colors.
   - 🕒 Time – local clock, extra clocks for other time zones, server time, 12/24-hour.
   - 🐳 Docker apps – all containers with status and ports, one-click open, start / stop / restart, logs.
   - 🧩 Docker Compose – projects grouped automatically; start, stop, restart, up, pull, down; edit the YAML in the browser.
   - 🔗 Links & logos – categories and tiles with automatic favicons and Dashboard Icons, emoji or image URLs; drag & drop; instant search.
   - 🏠 Home Assistant – show and toggle lights, switches, scenes and scripts, and send server metrics into Home Assistant.
   - ⌨ Web terminal – a real shell in the browser, for admins only.
   - 👥 Users & roles – first-run setup wizard, admin and user roles, per-user language and theme.
   - 🛠 Admin panel – general settings, appearance, integrations, users, API tokens, backup and restore.
   - 🎨 Fully customizable – 7 themes, accent color, corner radius, columns, card style, background image, widget order, custom CSS.
   - 🌍 Multi-language – English, Deutsch, Español, Français, easy to add more.

4. SCREENSHOTS
   A tabbed gallery (tabs: Dashboard, Terminal, Themes). Use the uploaded images dashboard.png, terminal.png and theme-dracula.png in browser frames. Add a button "Try the live demo" that links to https://YOUR_USER.github.io/homedash/preview.html (a clickable demo with sample data).

5. THEMES & CUSTOMIZATION
   Short section with colored swatches for the 7 themes: Auto, Dark, Light, Midnight, Nord, Dracula, Forest. Show a small code snippet:
   :root { --accent: #ff6b6b; --radius: 20px; }
   with the caption "Everything is a CSS variable. Add your own CSS in the admin panel."

6. INSTALL (id="install")
   Title "Running in under a minute". Show three tabs with copy buttons:
   Tab "Docker (recommended)":
     git clone https://github.com/YOUR_USER/homedash.git
     cd homedash
     ./install.sh
   Tab "Docker Compose":
     docker compose up -d --build
   Tab "No Docker (Python only)":
     ./install.sh --native
     # or simply
     python3 server.py
   Under the tabs: "Open http://<server-ip>:8080 and create your admin account. That's it." and a note "Use ./install.sh --port 9000 to pick another port."
   Show the docker-compose.yml example as a code block:
     services:
       homedash:
         build: .
         container_name: homedash
         restart: unless-stopped
         ports: ["8080:8080"]
         environment:
           - TZ=Europe/Berlin
         volumes:
           - ./data:/data
           - /var/run/docker.sock:/var/run/docker.sock
           - ./stacks:/compose
   Add a small table "Requirements": Any Linux server · Docker (optional) or Python 3.8+ · ~30 MB RAM · No database.

7. DOCKER LABELS
   Short section "Make containers look great" with this code block:
     labels:
       homedash.name: "Movies"
       homedash.url: "https://jellyfin.example.com"
       homedash.icon: "di:jellyfin"
       homedash.description: "Media server"
       homedash.hide: "false"

8. HOME ASSISTANT (id="home-assistant")
   Two columns:
   - "Show your smart home" – create a long-lived access token in Home Assistant, enter URL and token in Admin → Integrations, test the connection, pick entities.
   - "Send server stats to Home Assistant" – create a read-only API token in Admin → API tokens and paste the generated rest: block into configuration.yaml to get CPU, RAM and temperature sensors.

9. SECURITY (id="security")
   Title "Built with security in mind". Bullet cards:
   - Passwords hashed with PBKDF2-SHA256.
   - Signed, HttpOnly, SameSite=Strict sessions.
   - CSRF protection and login rate limiting.
   - Role-based access: only admins can use Docker actions, Compose, the terminal and admin pages.
   - Read-only API tokens.
   Add an honest warning box (amber): "The Docker socket and the terminal give admins root-equivalent control of the host. Only create admin accounts for people you trust, put HomeDash behind HTTPS if it is reachable from the internet, and disable the terminal if you don't need it."

10. COMPARISON (small, honest table)
    Rows: Live hardware stats, Docker control, Compose control, Web terminal, User accounts, Home Assistant, Zero dependencies. Columns: "Bookmark dashboards" vs "HomeDash". Mark HomeDash with green checks. Keep the tone fair; do not name or disparage specific competitor products.

11. FAQ (accordion)
    - Is HomeDash free? Yes, MIT licensed and open source.
    - Does it need a database? No. Settings are stored in simple JSON files in the data folder.
    - Can I run it without Docker? Yes, with only Python 3 (./install.sh --native or python3 server.py).
    - Does it work on a Raspberry Pi or a small VPS? Yes, it is very lightweight.
    - Can regular users change things? No. Users with the "user" role can view the dashboard and use Home Assistant tiles; admins manage everything.
    - How do I add a language? Copy the English block in static/i18n.js, translate it and register the code.
    - Do I need internet access? Only for logos/favicons and, optionally, the xterm.js terminal library. It also works offline with a built-in basic terminal.
    - How do I back up? Copy the data folder or use Admin → Backup to export settings.

12. FINAL CALL TO ACTION
    Large centered card: "Ready to take control of your homelab?" with buttons "Get started" and "View on GitHub".

13. FOOTER
    Logo, short description, links (GitHub, Issues, License, Documentation), language switcher, "Made for self-hosters. MIT License © 2026 HomeDash contributors."

=== EXTRA PAGES (simple, linked from the footer) ===
- /docs – a documentation page with a left sidebar: Installation, Configuration (table of environment variables below), Docker labels, Home Assistant, Security, Customizing, Adding a language.
- /imprint and /privacy – simple placeholder legal pages (the site itself collects no personal data and uses no tracking cookies).

Environment variables for the docs page:
  PORT / BIND – 8080 / 0.0.0.0 – listen port and address
  DATA_DIR – ./data – settings, users, tokens, icon cache
  DOCKER_SOCKET – /var/run/docker.sock – Docker API socket
  COMPOSE_DIR – /compose – folder with one sub-folder per Compose project
  HOST_ROOT – (empty) – where host files are mounted, e.g. /host
  DISK_PATHS – auto – choose disks, format Label:/path,Label2:/path2
  TERMINAL_HOST – 0 – 1 = shell on the host (needs pid: host and privileged: true)
  SECURE_COOKIE – 0 – set 1 when served over HTTPS
  SESSION_HOURS – 168 – login lifetime
  ADMIN_USER, ADMIN_PASSWORD – (empty) – create the first admin from the environment

=== TECHNICAL REQUIREMENTS ===
- Fast and lightweight, good Lighthouse scores, semantic HTML, proper headings, alt text on all images, keyboard accessible, sufficient color contrast.
- Copy-to-clipboard buttons on every code block, with a short "Copied!" confirmation.
- SEO: title "HomeDash – Self-hosted dashboard for homelabs, Docker & servers", meta description "Free open-source dashboard for self-hosters: hardware stats, Docker and Compose control, Home Assistant integration, web terminal and user accounts. Zero dependencies, easy install.", Open Graph and Twitter card tags, a favicon (indigo rounded square with a white house).
- No cookie banner needed (no tracking). Do not add analytics.
- Do not invent testimonials, user counts, download numbers or GitHub star counts. Use only the facts in this prompt.
- All GitHub links use https://github.com/YOUR_USER/homedash as a placeholder.
```

---

## Follow-up prompts (send these after the first version)

**Add the real screenshots**
```text
I'm uploading three screenshots: dashboard.png, terminal.png and theme-dracula.png. Use dashboard.png in the hero and the Dashboard tab, terminal.png in the Terminal tab and theme-dracula.png in the Themes tab. Put each in a browser-window frame with rounded corners and a soft indigo glow, and lazy-load them.
```

**Polish the design**
```text
Make the design feel more premium: add a subtle animated gradient glow behind the hero, slightly larger section spacing, hover lift on feature cards with an indigo border, and a thin gradient divider between sections. Keep it fast and avoid heavy animations.
```

**Finish the translations**
```text
Translate the entire site (all sections, FAQ, install section and footer) into German, Spanish and French, and make the language switcher change all text instantly. Remember the choice in the browser and default to the visitor's browser language.
```

**Replace the GitHub placeholder**
```text
Replace every occurrence of YOUR_USER with my GitHub username: <your-username>.
```

**Add a changelog and roadmap section**
```text
Add a "Roadmap" section after the FAQ with three columns: Now (everything listed as features), Next (more widgets, more themes, more languages) and Ideas (community suggestions via GitHub Issues). Keep it short and do not promise dates.
```

---

## Tips

- Upload `preview.html` to GitHub Pages (Settings → Pages) so the "Try the live demo" button works.
- Connect your own domain in Hostinger before publishing, then update the Open Graph URL.
- Keep the facts in the prompt unchanged. They match the real project, and the prompt tells Horizons not to invent statistics.
