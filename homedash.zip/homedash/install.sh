#!/usr/bin/env bash
# HomeDash installer.  Usage:
#   ./install.sh                      install with Docker (default) into /opt/homedash and start it
#   ./install.sh --native             install as a systemd service (needs python3 only, no Docker required)
#   ./install.sh --port 9000 --dir /srv/homedash
#   ./install.sh --uninstall
set -euo pipefail

DIR=/opt/homedash; PORT=8080; MODE=docker; UNINSTALL=0
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
while [ $# -gt 0 ]; do
  case "$1" in
    --native) MODE=native ;; --docker) MODE=docker ;; --uninstall) UNINSTALL=1 ;;
    --port) PORT="$2"; shift ;; --dir) DIR="$2"; shift ;;
    -h|--help) sed -n '2,7p' "$0"; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 1 ;;
  esac; shift
done
SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
say() { printf '\033[1;36m==>\033[0m %s\n' "$*"; }

if [ "$UNINSTALL" = 1 ]; then
  say "Stopping HomeDash (your data in $DIR/data is kept)"
  [ -f "$DIR/docker-compose.yml" ] && $SUDO docker compose -f "$DIR/docker-compose.yml" down || true
  if [ -f /etc/systemd/system/homedash.service ]; then $SUDO systemctl disable --now homedash || true; $SUDO rm -f /etc/systemd/system/homedash.service; $SUDO systemctl daemon-reload; fi
  exit 0
fi

say "Copying files to $DIR"
$SUDO mkdir -p "$DIR/data"
$SUDO cp -r "$SRC/server.py" "$SRC/static" "$SRC/Dockerfile" "$SRC/docker-compose.yml" "$DIR/"
$SUDO mkdir -p "$DIR/stacks"

# Best effort: bundle xterm.js so the terminal also works without internet access in the browser
if command -v curl >/dev/null 2>&1 && [ ! -f "$DIR/static/vendor/xterm.js" ]; then
  $SUDO mkdir -p "$DIR/static/vendor"; B=https://cdn.jsdelivr.net/npm
  ( $SUDO curl -fsSL -o "$DIR/static/vendor/xterm.js" $B/@xterm/xterm@5.5.0/lib/xterm.js &&
    $SUDO curl -fsSL -o "$DIR/static/vendor/xterm.css" $B/@xterm/xterm@5.5.0/css/xterm.css &&
    $SUDO curl -fsSL -o "$DIR/static/vendor/addon-fit.js" $B/@xterm/addon-fit@0.10.0/lib/addon-fit.js ) \
    || { say "xterm.js download skipped (built-in terminal will be used)"; $SUDO rm -rf "$DIR/static/vendor"; }
fi

TZ_NAME="$(cat /etc/timezone 2>/dev/null || timedatectl show -p Timezone --value 2>/dev/null || echo UTC)"

if [ "$MODE" = docker ]; then
  command -v docker >/dev/null 2>&1 || { echo "Docker is not installed. Install it (https://docs.docker.com/engine/install/) or use --native." >&2; exit 1; }
  $SUDO sed -i "s#\"8080:8080\"#\"$PORT:8080\"#; s#TZ=Europe/Berlin#TZ=$TZ_NAME#" "$DIR/docker-compose.yml"
  say "Building and starting the container"
  ( cd "$DIR" && $SUDO docker compose up -d --build )
else
  command -v python3 >/dev/null 2>&1 || { echo "python3 is required." >&2; exit 1; }
  say "Creating systemd service"
  $SUDO tee /etc/systemd/system/homedash.service >/dev/null <<UNIT
[Unit]
Description=HomeDash dashboard
After=network-online.target docker.service

[Service]
WorkingDirectory=$DIR
Environment=PORT=$PORT DATA_DIR=$DIR/data COMPOSE_DIR=$DIR/stacks TZ=$TZ_NAME
ExecStart=$(command -v python3) -u $DIR/server.py
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
UNIT
  $SUDO systemctl daemon-reload && $SUDO systemctl enable --now homedash
fi

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"; IP="${IP:-localhost}"
say "Done!  Open  http://$IP:$PORT  and create your admin account."
