#!/usr/bin/env python3
"""HomeDash - self-hosted dashboard for homelabs, VPS and servers.

Pure Python standard library: no pip install needed.
"""
import base64, copy, fcntl, glob, hashlib, hmac, http.client, json, mimetypes, os, platform
import pty, re, secrets, shutil, socket, ssl, struct, subprocess, sys, termios, threading
import time, urllib.parse, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

VERSION = "1.0.0"
BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
DATA = Path(os.environ.get("DATA_DIR", BASE / "data"))
PORT = int(os.environ.get("PORT", "8080"))
BIND = os.environ.get("BIND", "0.0.0.0")
DOCKER_SOCK = os.environ.get("DOCKER_SOCKET", "/var/run/docker.sock")
COMPOSE_DIR = Path(os.environ.get("COMPOSE_DIR", "/compose"))
HOST_ROOT = os.environ.get("HOST_ROOT", "")  # e.g. /host when host files are mounted there
SESSION_TTL = int(os.environ.get("SESSION_HOURS", "168")) * 3600
SECURE_COOKIE = os.environ.get("SECURE_COOKIE", "0") == "1"
MAX_BODY = 2 * 1024 * 1024

LOCK = threading.RLock()


# --------------------------------------------------------------------------- storage
def load(name, default):
    try:
        return json.loads((DATA / name).read_text())
    except Exception:
        return copy.deepcopy(default)


def save(name, obj):
    with LOCK:
        DATA.mkdir(parents=True, exist_ok=True)
        tmp = DATA / (name + ".tmp")
        tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False))
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        os.replace(tmp, DATA / name)


def get_secret():
    p = DATA / "secret.key"
    if not p.exists():
        DATA.mkdir(parents=True, exist_ok=True)
        p.write_text(secrets.token_hex(32))
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
    return p.read_text().strip().encode()


SECRET = None

WIDGET_IDS = ["clock", "system", "links", "docker", "compose", "ha"]
THEMES = ["auto", "dark", "light", "midnight", "nord", "dracula", "forest"]
LANGS = ["en", "de", "es", "fr"]

DEFAULT_CONFIG = {
    "title": "HomeDash",
    "subtitle": "",
    "language": "en",
    "theme": "auto",
    "accent": "#6366f1",
    "background": "",
    "radius": 14,
    "columns": 4,
    "card_style": "glass",  # glass | solid | flat
    "custom_css": "",
    "timezone": "",
    "time24": True,
    "clock_zones": [],
    "widgets": [{"id": w, "on": True} for w in WIDGET_IDS],
    "categories": [
        {"name": "Favorites", "links": [
            {"name": "GitHub", "url": "https://github.com", "icon": "di:github", "desc": ""},
            {"name": "Docker Hub", "url": "https://hub.docker.com", "icon": "di:docker", "desc": ""},
            {"name": "selfh.st", "url": "https://selfh.st", "icon": "", "desc": "Self-hosting news"},
        ]},
    ],
    "ha": {"url": "", "token": "", "verify_tls": True, "entities": []},
    "terminal": {"enabled": True},
    "docker": {"autolinks": True},
}


def deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def get_config():
    return deep_merge(DEFAULT_CONFIG, load("config.json", {}))


URL_RE = re.compile(r"^(https?://[^\s\"'<>]+|/[^\s\"'<>]*|#[^\s\"'<>]*)$", re.I)


def s(v, n=200):
    return str(v if v is not None else "").strip()[:n]


def sanitize_config(new, old):
    c = copy.deepcopy(old)
    c["title"] = s(new.get("title", c["title"]), 60) or "HomeDash"
    c["subtitle"] = s(new.get("subtitle", c["subtitle"]), 120)
    c["language"] = new.get("language") if new.get("language") in LANGS else c["language"]
    c["theme"] = new.get("theme") if new.get("theme") in THEMES else c["theme"]
    acc = s(new.get("accent", c["accent"]), 9)
    c["accent"] = acc if re.match(r"^#[0-9a-fA-F]{6}$", acc) else c["accent"]
    bg = s(new.get("background", c["background"]), 500)
    c["background"] = bg if (bg == "" or re.match(r"^(https?://|/)[^\"'()\s]+$", bg)) else ""
    c["radius"] = max(0, min(40, int(new.get("radius", c["radius"]) or 0)))
    c["columns"] = max(1, min(8, int(new.get("columns", c["columns"]) or 4)))
    c["card_style"] = new.get("card_style") if new.get("card_style") in ("glass", "solid", "flat") else c["card_style"]
    c["custom_css"] = s(new.get("custom_css", c["custom_css"]), 50000)
    c["timezone"] = s(new.get("timezone", c["timezone"]), 60)
    c["time24"] = bool(new.get("time24", c["time24"]))
    c["clock_zones"] = [s(z, 60) for z in (new.get("clock_zones") or [])][:6] if "clock_zones" in new else c["clock_zones"]
    if "widgets" in new:
        seen, ws = set(), []
        for w in new["widgets"] or []:
            if isinstance(w, dict) and w.get("id") in WIDGET_IDS and w["id"] not in seen:
                seen.add(w["id"])
                ws.append({"id": w["id"], "on": bool(w.get("on", True))})
        ws += [{"id": w, "on": True} for w in WIDGET_IDS if w not in seen]
        c["widgets"] = ws
    if "categories" in new:
        cats = []
        for cat in (new["categories"] or [])[:50]:
            if not isinstance(cat, dict):
                continue
            links = []
            for l in (cat.get("links") or [])[:200]:
                if not isinstance(l, dict):
                    continue
                url = s(l.get("url"), 500)
                if not URL_RE.match(url):
                    continue
                links.append({"name": s(l.get("name"), 60) or url, "url": url,
                              "icon": s(l.get("icon"), 500), "desc": s(l.get("desc"), 120)})
            cats.append({"name": s(cat.get("name"), 60), "links": links})
        c["categories"] = cats
    if isinstance(new.get("ha"), dict):
        ha = new["ha"]
        url = s(ha.get("url"), 300).rstrip("/")
        token = s(ha.get("token"), 2000)
        if token == "********":
            token = old["ha"].get("token", "")
        ents = []
        for e in (ha.get("entities") or [])[:100]:
            if isinstance(e, dict) and re.match(r"^[a-z_]+\.[a-zA-Z0-9_]+$", s(e.get("id"))):
                ents.append({"id": s(e["id"]), "name": s(e.get("name"), 60)})
        c["ha"] = {"url": url if (url == "" or re.match(r"^https?://", url)) else "",
                   "token": token, "verify_tls": bool(ha.get("verify_tls", True)), "entities": ents}
    if isinstance(new.get("terminal"), dict):
        c["terminal"] = {"enabled": bool(new["terminal"].get("enabled", True))}
    if isinstance(new.get("docker"), dict):
        c["docker"] = {"autolinks": bool(new["docker"].get("autolinks", True))}
    return c


# --------------------------------------------------------------------------- users / auth
def hash_pw(pw, salt=None):
    salt = salt or secrets.token_hex(8)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 200_000).hex()
    return f"pbkdf2${salt}${h}"


def check_pw(pw, stored):
    try:
        _, salt, h = stored.split("$")
        return hmac.compare_digest(hash_pw(pw, salt).split("$")[2], h)
    except Exception:
        return False


def users():
    return load("users.json", [])


def find_user(name):
    for u in users():
        if u["username"].lower() == name.lower():
            return u
    return None


USER_RE = re.compile(r"^[A-Za-z0-9_.@-]{2,40}$")


def add_user(username, password, role="user", language=""):
    if not USER_RE.match(username):
        raise ValueError("invalid_username")
    if len(password) < 8:
        raise ValueError("password_short")
    with LOCK:
        us = users()
        if any(u["username"].lower() == username.lower() for u in us):
            raise ValueError("user_exists")
        us.append({"username": username, "password": hash_pw(password), "role": "admin" if role == "admin" else "user",
                   "language": language if language in LANGS else "", "theme": "", "pv": secrets.token_hex(4),
                   "created": int(time.time())})
        save("users.json", us)


def sign(user):
    exp = int(time.time()) + SESSION_TTL
    b = base64.urlsafe_b64encode(user["username"].encode()).decode().rstrip("=")
    mac = hmac.new(SECRET, f"{b}.{exp}.{user['pv']}".encode(), hashlib.sha256).hexdigest()
    return f"{b}.{exp}.{mac}"


def verify_cookie(val):
    try:
        b, exp, mac = val.split(".")
        if int(exp) < time.time():
            return None
        name = base64.urlsafe_b64decode(b + "=" * (-len(b) % 4)).decode()
        u = find_user(name)
        if not u:
            return None
        good = hmac.new(SECRET, f"{b}.{exp}.{u['pv']}".encode(), hashlib.sha256).hexdigest()
        return u if hmac.compare_digest(good, mac) else None
    except Exception:
        return None


FAILS = {}


def rate_limited(ip):
    now = time.time()
    FAILS[ip] = [t for t in FAILS.get(ip, []) if now - t < 300]
    return len(FAILS[ip]) >= 8


# --------------------------------------------------------------------------- system stats
def rd(p, default=""):
    try:
        return Path(p).read_text(errors="ignore").strip()
    except Exception:
        return default


def cpu_times():
    out = {}
    for line in rd("/proc/stat").splitlines():
        if line.startswith("cpu"):
            p = line.split()
            v = list(map(int, p[1:]))
            idle = v[3] + (v[4] if len(v) > 4 else 0)
            out[p[0]] = (idle, sum(v[:8]))
    return out


def net_bytes():
    rx = tx = 0
    for line in rd("/proc/net/dev").splitlines()[2:]:
        name, _, rest = line.partition(":")
        name = name.strip()
        if name == "lo" or name.startswith(("veth", "docker", "br-", "virbr", "cni", "flannel")):
            continue
        f = rest.split()
        if len(f) >= 9:
            rx += int(f[0])
            tx += int(f[8])
    return rx, tx


STATE = {"cpu": 0.0, "cores": [], "rx": 0.0, "tx": 0.0}


def sampler():
    prev, pn, pt = cpu_times(), net_bytes(), time.time()
    while True:
        time.sleep(2)
        try:
            cur, cn, ct = cpu_times(), net_bytes(), time.time()
            pcts = {}
            for k, (idle, total) in cur.items():
                pi, ptot = prev.get(k, (idle, total))
                dt = total - ptot
                pcts[k] = 0.0 if dt <= 0 else round(100 * (1 - (idle - pi) / dt), 1)
            STATE["cpu"] = pcts.get("cpu", 0.0)
            STATE["cores"] = [v for k, v in sorted(pcts.items(), key=lambda kv: (len(kv[0]), kv[0])) if k != "cpu"]
            dt = max(ct - pt, 0.001)
            STATE["rx"] = max(0, (cn[0] - pn[0]) / dt)
            STATE["tx"] = max(0, (cn[1] - pn[1]) / dt)
            prev, pn, pt = cur, cn, ct
        except Exception:
            pass


def os_release():
    for p in (f"{HOST_ROOT}/etc/os-release", "/etc/os-release"):
        t = rd(p)
        if t:
            m = re.search(r'^PRETTY_NAME="?([^"\n]+)"?', t, re.M)
            if m:
                return m.group(1)
    return platform.platform()


def cpu_model():
    t = rd("/proc/cpuinfo")
    for key in ("model name", "Model", "Hardware"):
        m = re.search(rf"^{key}\s*:\s*(.+)$", t, re.M)
        if m:
            return m.group(1).strip()
    dt = rd("/proc/device-tree/model").strip("\0")
    return dt or platform.processor() or platform.machine()


def meminfo():
    m = {}
    for line in rd("/proc/meminfo").splitlines():
        k, _, v = line.partition(":")
        try:
            m[k] = int(v.split()[0]) * 1024
        except Exception:
            pass
    total = m.get("MemTotal", 0)
    avail = m.get("MemAvailable", m.get("MemFree", 0))
    return {"total": total, "used": total - avail, "swap_total": m.get("SwapTotal", 0),
            "swap_used": m.get("SwapTotal", 0) - m.get("SwapFree", 0), "cached": m.get("Cached", 0)}


def disks():
    out, seen, targets = [], set(), []
    env = os.environ.get("DISK_PATHS", "")
    if env:
        for item in env.split(","):
            label, sep, p = item.strip().partition(":")
            targets.append((label if sep else p, p if sep else label, ""))
    else:
        real = {"ext2", "ext3", "ext4", "xfs", "btrfs", "zfs", "vfat", "ntfs", "ntfs3", "fuseblk", "f2fs", "exfat", "overlay", "nfs", "nfs4", "cifs"}
        for line in rd("/proc/mounts").splitlines():
            p = line.split()
            if len(p) < 3:
                continue
            dev, mp, fs = p[0], p[1].replace("\\040", " "), p[2]
            if fs not in real or mp.startswith(("/etc/", "/var/lib/docker", "/var/lib/kubelet", "/snap", "/run", "/proc", "/sys", "/dev", "/usr/lib")):
                continue
            if fs == "overlay" and mp != "/":
                continue
            targets.append((mp, mp, fs))
    for label, path, fs in targets:
        try:
            u = shutil.disk_usage(path)
        except Exception:
            continue
        key = (u.total, u.used)
        if key in seen or u.total == 0:
            continue
        seen.add(key)
        out.append({"label": label, "path": path, "fs": fs, "total": u.total, "used": u.used})
    return out[:12]


def temps():
    out = []
    for hw in sorted(glob.glob("/sys/class/hwmon/hwmon*")):
        name = rd(hw + "/name")
        for f in sorted(glob.glob(hw + "/temp*_input")):
            try:
                v = int(rd(f)) / 1000
            except Exception:
                continue
            if not -20 < v < 150:
                continue
            base = f[:-6]
            hi, crit = rd(base + "_max"), rd(base + "_crit")
            out.append({"group": name, "label": rd(base + "_label") or os.path.basename(base), "value": round(v, 1),
                        "max": int(hi) / 1000 if hi.lstrip("-").isdigit() else None,
                        "crit": int(crit) / 1000 if crit.lstrip("-").isdigit() else None})
    if not out:
        for z in sorted(glob.glob("/sys/class/thermal/thermal_zone*")):
            try:
                v = int(rd(z + "/temp")) / 1000
            except Exception:
                continue
            out.append({"group": "thermal", "label": rd(z + "/type") or os.path.basename(z), "value": round(v, 1), "max": None, "crit": None})
    return out


_gpu = {"t": 0, "v": []}


def gpus():
    if time.time() - _gpu["t"] < 5:
        return _gpu["v"]
    res = []
    if shutil.which("nvidia-smi"):
        try:
            o = subprocess.run(["nvidia-smi", "--query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total",
                                "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=4).stdout
            for line in o.strip().splitlines():
                n, t, u, mu, mt = [x.strip() for x in line.split(",")]
                res.append({"name": n, "temp": float(t), "util": float(u), "mem_used": float(mu) * 1048576, "mem_total": float(mt) * 1048576})
        except Exception:
            pass
    _gpu.update(t=time.time(), v=res)
    return res


def server_tz():
    return os.environ.get("TZ") or rd("/etc/timezone") or time.tzname[0]


def system_info():
    up = 0.0
    try:
        up = float(rd("/proc/uptime").split()[0])
    except Exception:
        pass
    try:
        load = os.getloadavg()
    except Exception:
        load = (0, 0, 0)
    return {
        "hostname": rd(f"{HOST_ROOT}/etc/hostname") or socket.gethostname(),
        "os": os_release(), "kernel": platform.release(), "arch": platform.machine(),
        "cpu": {"model": cpu_model(), "cores": os.cpu_count(), "usage": STATE["cpu"], "per_core": STATE["cores"], "load": load},
        "memory": meminfo(), "disks": disks(), "temps": temps(), "gpus": gpus(),
        "net": {"rx": STATE["rx"], "tx": STATE["tx"]},
        "uptime": up, "time": {"epoch": time.time(), "tz": server_tz()},
        "version": VERSION,
    }


# --------------------------------------------------------------------------- docker
class UnixConn(http.client.HTTPConnection):
    def __init__(self, path, timeout=10):
        super().__init__("localhost", timeout=timeout)
        self._path = path

    def connect(self):
        s_ = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s_.settimeout(self.timeout)
        s_.connect(self._path)
        self.sock = s_


class DockerError(Exception):
    pass


def docker_api(method, path, body=None, raw=False, timeout=15):
    if not os.path.exists(DOCKER_SOCK):
        raise DockerError("Docker socket not found: " + DOCKER_SOCK)
    c = UnixConn(DOCKER_SOCK, timeout)
    try:
        hdr = {"Content-Type": "application/json"} if body is not None else {}
        c.request(method, path, body=json.dumps(body) if body is not None else None, headers=hdr)
        r = c.getresponse()
        data = r.read()
        if r.status >= 400:
            try:
                raise DockerError(json.loads(data).get("message", f"HTTP {r.status}"))
            except (ValueError, AttributeError):
                raise DockerError(f"HTTP {r.status}")
        if raw:
            return data
        return json.loads(data) if data else {}
    except (OSError, http.client.HTTPException) as e:
        raise DockerError(str(e))
    finally:
        c.close()


def demux(data):
    out, i, ok = [], 0, True
    while i + 8 <= len(data):
        if data[i] not in (0, 1, 2) or data[i + 1:i + 4] != b"\0\0\0":
            ok = False
            break
        n = struct.unpack(">I", data[i + 4:i + 8])[0]
        out.append(data[i + 8:i + 8 + n])
        i += 8 + n
    return b"".join(out) if ok and out else data


def list_containers():
    items = docker_api("GET", "/containers/json?all=1")
    res = []
    for c in items:
        lab = c.get("Labels") or {}
        if lab.get("homedash.hide") == "true":
            continue
        ports, seen = [], set()
        for p in c.get("Ports") or []:
            if p.get("PublicPort"):
                k = (p["PublicPort"], p.get("Type"))
                if k not in seen:
                    seen.add(k)
                    ports.append({"public": p["PublicPort"], "private": p.get("PrivatePort"), "type": p.get("Type", "tcp")})
        name = (c.get("Names") or ["/?"])[0].lstrip("/")
        res.append({
            "id": c["Id"][:12], "name": lab.get("homedash.name") or name, "container": name, "image": c.get("Image", ""),
            "state": c.get("State", ""), "status": c.get("Status", ""), "created": c.get("Created"), "ports": sorted(ports, key=lambda x: x["public"]),
            "project": lab.get("com.docker.compose.project", ""), "service": lab.get("com.docker.compose.service", ""),
            "workdir": lab.get("com.docker.compose.project.working_dir", ""), "config_files": lab.get("com.docker.compose.project.config_files", ""),
            "url": lab.get("homedash.url", ""), "icon": lab.get("homedash.icon", ""), "desc": lab.get("homedash.description", ""),
        })
    res.sort(key=lambda c: (c["state"] != "running", c["name"].lower()))
    return res


def compose_files():
    out = []
    if not COMPOSE_DIR.is_dir():
        return out
    base = COMPOSE_DIR.resolve()
    for root, dirs, files in os.walk(base):
        depth = len(Path(root).relative_to(base).parts)
        if depth >= 3:
            dirs[:] = []
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("node_modules", "data")]
        for f in files:
            if f.endswith((".yml", ".yaml")) or f == ".env":
                out.append(str(Path(root, f).relative_to(base)))
        if len(out) > 300:
            break
    return sorted(out)


def safe_compose_path(rel):
    base = COMPOSE_DIR.resolve()
    p = (base / rel).resolve()
    if base not in p.parents or not (p.name.endswith((".yml", ".yaml")) or p.name == ".env"):
        raise ValueError("bad_path")
    return p


COMPOSE_NAMES = ("compose.yaml", "compose.yml", "docker-compose.yaml", "docker-compose.yml")


def find_compose_file(project, cfg_files="", workdir=""):
    cands = []
    for f in (cfg_files or "").split(","):
        if f.strip():
            cands.append(Path(f.strip()))
            if workdir:
                cands.append(COMPOSE_DIR / Path(workdir).name / Path(f.strip()).name)
    for n in COMPOSE_NAMES:
        cands.append(COMPOSE_DIR / project / n)
    for c in cands:
        if c.is_file():
            return c
    return None


def compose_projects():
    cons = list_containers()
    projects = {}
    for c in cons:
        if not c["project"]:
            continue
        p = projects.setdefault(c["project"], {"name": c["project"], "services": [], "running": 0,
                                               "config_files": c["config_files"], "workdir": c["workdir"]})
        p["services"].append({"id": c["id"], "service": c["service"], "container": c["container"], "state": c["state"],
                              "image": c["image"], "status": c["status"]})
        if c["state"] == "running":
            p["running"] += 1
    if COMPOSE_DIR.is_dir():
        for d in sorted(COMPOSE_DIR.iterdir()):
            if d.is_dir() and any((d / n).is_file() for n in COMPOSE_NAMES):
                nm = re.sub(r"[^a-z0-9_-]", "", d.name.lower())
                projects.setdefault(nm, {"name": nm, "services": [], "running": 0, "config_files": "", "workdir": str(d)})
    for p in projects.values():
        f = find_compose_file(p["name"], p["config_files"], p["workdir"])
        p["file"] = str(f.relative_to(COMPOSE_DIR.resolve())) if f and COMPOSE_DIR.resolve() in f.resolve().parents else ""
        p["can_cli"] = bool(f and shutil.which("docker"))
        p["total"] = len(p["services"])
    return sorted(projects.values(), key=lambda p: p["name"])


# --------------------------------------------------------------------------- home assistant
def ha_call(method, path, body=None):
    ha = get_config()["ha"]
    if not ha["url"] or not ha["token"]:
        raise RuntimeError("not_configured")
    req = urllib.request.Request(ha["url"] + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Authorization": "Bearer " + ha["token"], "Content-Type": "application/json"})
    ctx = None if ha.get("verify_tls", True) else ssl._create_unverified_context()
    with urllib.request.urlopen(req, timeout=8, context=ctx) as r:
        return json.loads(r.read() or b"null")


HA_ALLOWED = {("light", "toggle"), ("light", "turn_on"), ("light", "turn_off"), ("switch", "toggle"), ("switch", "turn_on"), ("switch", "turn_off"),
              ("input_boolean", "toggle"), ("fan", "toggle"), ("scene", "turn_on"), ("script", "turn_on"), ("automation", "toggle"),
              ("automation", "trigger"), ("button", "press"), ("input_button", "press"), ("cover", "toggle"), ("media_player", "media_play_pause")}


# --------------------------------------------------------------------------- icons / favicons
ICON_DIR_NAME = "icons"
_neg = {}


def fetch(url, maxb=600_000, timeout=5):
    req = urllib.request.Request(url, headers={"User-Agent": "HomeDash/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout, context=ssl._create_unverified_context()) as r:
        ct = r.headers.get_content_type()
        data = r.read(maxb + 1)
        if len(data) > maxb:
            raise ValueError("too large")
        return data, ct, r.geturl()


def is_image(data, ct):
    return ct.startswith("image/") or data[:4] in (b"\x00\x00\x01\x00",) or data[:5] == b"<svg " or data[:5] == b"<?xml"


def get_icon(kind, val):
    key = hashlib.sha1(f"{kind}:{val}".encode()).hexdigest()
    d = DATA / ICON_DIR_NAME
    d.mkdir(parents=True, exist_ok=True)
    f, meta = d / key, d / (key + ".type")
    if f.exists():
        return f.read_bytes(), meta.read_text()
    if time.time() - _neg.get(key, 0) < 3600:
        return None
    try:
        if kind == "di":
            if not re.match(r"^[a-z0-9._-]{1,60}$", val):
                return None
            data, ct, _ = fetch(f"https://cdn.jsdelivr.net/gh/homarr-labs/dashboard-icons/png/{val}.png")
        elif kind == "src":
            data, ct, _ = fetch(val)
        else:  # fav
            u = urllib.parse.urlparse(val)
            origin = f"{u.scheme}://{u.netloc}"
            data = ct = None
            try:
                data, ct, _ = fetch(origin + "/favicon.ico")
                if not is_image(data, ct):
                    data = None
            except Exception:
                data = None
            if data is None:
                html, _, final = fetch(origin + "/", maxb=300_000)
                m = re.search(rb'<link[^>]+rel=["\'][^"\']*icon[^"\']*["\'][^>]*href=["\']([^"\']+)["\']', html, re.I) or \
                    re.search(rb'<link[^>]+href=["\']([^"\']+)["\'][^>]*rel=["\'][^"\']*icon', html, re.I)
                if not m:
                    raise ValueError("no icon")
                data, ct, _ = fetch(urllib.parse.urljoin(final, m.group(1).decode()))
        if not is_image(data, ct):
            raise ValueError("not an image")
        if ct == "application/octet-stream" or not ct.startswith("image/"):
            ct = "image/x-icon" if data[:4] == b"\x00\x00\x01\x00" else "image/svg+xml" if data[:5] in (b"<svg ", b"<?xml") else "image/png"
        f.write_bytes(data)
        meta.write_text(ct)
        return data, ct
    except Exception:
        _neg[key] = time.time()
        return None


# --------------------------------------------------------------------------- terminal
TERMS = {}
TERM_LOCK = threading.Lock()


class Term:
    def __init__(self, owner):
        self.owner = owner
        self.cond = threading.Condition()
        self.buf = bytearray()
        self.base = 0
        self.alive = True
        self.last = time.time()
        pid, fd = pty.fork()
        if pid == 0:
            env = {k: v for k, v in os.environ.items() if k not in ("DATA_DIR", "ADMIN_PASSWORD")}
            env.update(TERM="xterm-256color", LANG=os.environ.get("LANG", "C.UTF-8"))
            try:
                os.chdir(os.environ.get("TERMINAL_CWD") or os.path.expanduser("~") or "/")
            except Exception:
                pass
            if os.environ.get("TERMINAL_HOST") == "1" and shutil.which("nsenter"):
                os.execvpe("nsenter", ["nsenter", "-t", "1", "-m", "-u", "-i", "-n", "-p", "--", "sh", "-c",
                                       "command -v bash >/dev/null && exec bash -l || exec sh -l"], env)
            sh = os.environ.get("TERMINAL_SHELL") or shutil.which("bash") or "/bin/sh"
            os.execvpe(sh, [sh, "-l"] if sh.endswith("bash") else [sh], env)
        self.pid, self.fd = pid, fd
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        while True:
            try:
                d = os.read(self.fd, 65536)
            except OSError:
                d = b""
            if not d:
                break
            with self.cond:
                self.buf += d
                if len(self.buf) > 262144:
                    cut = len(self.buf) - 262144
                    del self.buf[:cut]
                    self.base += cut
                self.cond.notify_all()
        with self.cond:
            self.alive = False
            self.cond.notify_all()
        try:
            os.waitpid(self.pid, 0)
        except Exception:
            pass

    def write(self, data):
        self.last = time.time()
        if self.alive:
            os.write(self.fd, data)

    def resize(self, cols, rows):
        try:
            fcntl.ioctl(self.fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        except Exception:
            pass

    def close(self):
        try:
            os.kill(self.pid, 9)
        except Exception:
            pass
        try:
            os.close(self.fd)
        except Exception:
            pass


def reap_terms():
    while True:
        time.sleep(60)
        with TERM_LOCK:
            for k, t in list(TERMS.items()):
                if (not t.alive and time.time() - t.last > 300) or time.time() - t.last > 6 * 3600:
                    t.close()
                    del TERMS[k]


# --------------------------------------------------------------------------- HTTP
SEC_HEADERS = {
    "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "same-origin",
    "Content-Security-Policy": "default-src 'self'; img-src 'self' https: http: data:; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
                               "script-src 'self' https://cdn.jsdelivr.net; connect-src 'self'; font-src 'self' data: https://cdn.jsdelivr.net; frame-ancestors 'none'",
}
API_READ_ONLY = {"/api/system", "/api/docker/containers", "/api/compose/projects"}


class Handler(BaseHTTPRequestHandler):
    server_version = "HomeDash"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        if os.environ.get("ACCESS_LOG") == "1":
            sys.stderr.write("%s %s\n" % (self.client_address[0], fmt % args))

    # -- helpers
    def _headers(self, code, ctype, length=None, extra=()):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        if length is not None:
            self.send_header("Content-Length", str(length))
        for k, v in SEC_HEADERS.items():
            self.send_header(k, v)
        for k, v in extra:
            self.send_header(k, v)
        self.end_headers()

    def json(self, obj, code=200, extra=()):
        body = json.dumps(obj).encode()
        self._headers(code, "application/json", len(body), [("Cache-Control", "no-store"), *extra])
        self.wfile.write(body)

    def err(self, code, msg):
        self.json({"error": msg}, code)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > MAX_BODY:
            raise ValueError("too_large")
        if not n:
            return {}
        return json.loads(self.rfile.read(n) or b"{}")

    def cookie(self, name):
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == name:
                return v
        return ""

    def current_user(self):
        h = self.headers.get("Authorization", "")
        if h.startswith("Bearer "):
            th = hashlib.sha256(h[7:].strip().encode()).hexdigest()
            for t in load("tokens.json", []):
                if hmac.compare_digest(t["hash"], th):
                    return {"username": "api:" + t["name"], "role": "api"}
            return None
        v = self.cookie("hd_session")
        return verify_cookie(v) if v else None

    # -- dispatch
    def do_GET(self):
        self.dispatch("GET")

    def do_POST(self):
        self.dispatch("POST")

    def do_PUT(self):
        self.dispatch("PUT")

    def do_DELETE(self):
        self.dispatch("DELETE")

    def dispatch(self, method):
        try:
            u = urllib.parse.urlparse(self.path)
            path, q = u.path, {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
            if path.startswith("/api/"):
                if method != "GET" and self.headers.get("X-Requested-With") != "homedash" and not self.headers.get("Authorization"):
                    return self.err(403, "csrf")
                return self.api(method, path, q)
            if path == "/healthz":
                return self.json({"ok": True})
            return self.static(path)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except ValueError as e:
            self.err(400, str(e))
        except Exception as e:  # noqa
            sys.stderr.write(f"error: {e!r}\n")
            try:
                self.err(500, "server_error")
            except Exception:
                pass

    def static(self, path):
        if path in ("/", ""):
            path = "/index.html"
        p = (STATIC / path.lstrip("/")).resolve()
        if STATIC.resolve() not in p.parents or not p.is_file():
            if "." in path.rsplit("/", 1)[-1]:
                return self.err(404, "not_found")
            p = STATIC / "index.html"  # SPA fallback
        data = p.read_bytes()
        ct = mimetypes.guess_type(str(p))[0] or "application/octet-stream"
        if ct.startswith("text/") or ct in ("application/javascript", "application/json"):
            ct += "; charset=utf-8"
        self._headers(200, ct, len(data), [("Cache-Control", "no-cache")])
        self.wfile.write(data)

    # -- API
    def api(self, method, path, q):
        cfg_pub = None
        # public endpoints
        if path == "/api/public" and method == "GET":
            c = get_config()
            return self.json({"title": c["title"], "language": c["language"], "theme": c["theme"], "accent": c["accent"],
                              "background": c["background"], "radius": c["radius"], "needs_setup": len(users()) == 0, "version": VERSION})
        if path == "/api/setup" and method == "POST":
            if users():
                return self.err(403, "already_setup")
            b = self.body()
            try:
                add_user(s(b.get("username"), 40), str(b.get("password", "")), "admin", s(b.get("language"), 5))
            except ValueError as e:
                return self.err(400, str(e))
            return self.json({"ok": True})
        if path == "/api/login" and method == "POST":
            ip = self.client_address[0]
            if rate_limited(ip):
                return self.err(429, "too_many")
            b = self.body()
            u = find_user(s(b.get("username"), 40))
            if not u or not check_pw(str(b.get("password", "")), u["password"]):
                FAILS.setdefault(ip, []).append(time.time())
                time.sleep(0.4)
                return self.err(401, "invalid_login")
            ck = f"hd_session={sign(u)}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}" + ("; Secure" if SECURE_COOKIE else "")
            return self.json({"ok": True}, extra=[("Set-Cookie", ck)])
        if path == "/api/logout" and method == "POST":
            return self.json({"ok": True}, extra=[("Set-Cookie", "hd_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0")])

        user = self.current_user()
        if not user:
            return self.err(401, "unauthorized")
        admin = user["role"] == "admin"
        if user["role"] == "api" and not (method == "GET" and path in API_READ_ONLY):
            return self.err(403, "forbidden")

        def need_admin():
            if not admin:
                self.err(403, "forbidden")
            return admin

        # ---- profile
        if path == "/api/me":
            if method == "GET":
                return self.json({"username": user["username"], "role": user["role"], "language": user.get("language", ""), "theme": user.get("theme", "")})
            if method == "PUT":
                b = self.body()
                with LOCK:
                    us = users()
                    me = next(x for x in us if x["username"] == user["username"])
                    if "language" in b:
                        me["language"] = b["language"] if b["language"] in LANGS else ""
                    if "theme" in b:
                        me["theme"] = b["theme"] if b["theme"] in THEMES else ""
                    extra = []
                    if b.get("password"):
                        if not check_pw(str(b.get("current_password", "")), me["password"]):
                            return self.err(400, "invalid_login")
                        if len(b["password"]) < 8:
                            return self.err(400, "password_short")
                        me["password"] = hash_pw(b["password"])
                        me["pv"] = secrets.token_hex(4)
                        extra = [("Set-Cookie", f"hd_session={sign(me)}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}")]
                    save("users.json", us)
                return self.json({"ok": True}, extra=extra)

        # ---- config
        if path == "/api/config":
            cfg = get_config()
            if method == "GET":
                if not admin:
                    cfg["ha"] = {"configured": bool(cfg["ha"]["url"] and cfg["ha"]["token"]), "entities": cfg["ha"]["entities"]}
                else:
                    cfg["ha"]["token"] = "********" if cfg["ha"]["token"] else ""
                return self.json(cfg)
            if method == "PUT":
                if not need_admin():
                    return
                new = sanitize_config(self.body(), cfg)
                save("config.json", new)
                return self.json({"ok": True})

        # ---- system
        if path == "/api/system" and method == "GET":
            return self.json(system_info())

        # ---- docker
        if path == "/api/docker/containers" and method == "GET":
            try:
                return self.json({"available": True, "containers": list_containers()})
            except DockerError as e:
                return self.json({"available": False, "error": str(e), "containers": []})
        if path == "/api/docker/action" and method == "POST":
            if not need_admin():
                return
            b = self.body()
            cid, act = s(b.get("id"), 80), b.get("action")
            if act not in ("start", "stop", "restart", "pause", "unpause") or not re.match(r"^[a-zA-Z0-9_.-]+$", cid):
                return self.err(400, "bad_request")
            try:
                docker_api("POST", f"/containers/{cid}/{act}", timeout=60, raw=True)
            except DockerError as e:
                return self.err(502, str(e))
            return self.json({"ok": True})
        if path == "/api/docker/logs" and method == "GET":
            if not need_admin():
                return
            cid = q.get("id", "")
            if not re.match(r"^[a-zA-Z0-9_.-]+$", cid):
                return self.err(400, "bad_request")
            try:
                tail = max(1, min(2000, int(q.get("tail", 200))))
                data = docker_api("GET", f"/containers/{cid}/logs?stdout=1&stderr=1&tail={tail}", raw=True, timeout=15)
            except DockerError as e:
                return self.err(502, str(e))
            return self.json({"logs": demux(data).decode(errors="replace")})

        # ---- compose
        if path == "/api/compose/projects" and method == "GET":
            try:
                return self.json({"available": True, "projects": compose_projects(), "dir": str(COMPOSE_DIR) if COMPOSE_DIR.is_dir() else ""})
            except DockerError as e:
                return self.json({"available": False, "error": str(e), "projects": []})
        if path == "/api/compose/action" and method == "POST":
            if not need_admin():
                return
            b = self.body()
            name, act = s(b.get("project"), 80), b.get("action")
            if act not in ("start", "stop", "restart", "up", "down", "pull") or not re.match(r"^[a-z0-9_-]+$", name):
                return self.err(400, "bad_request")
            projs = {p["name"]: p for p in compose_projects()}
            p = projs.get(name)
            if not p:
                return self.err(404, "not_found")
            try:
                if act in ("start", "stop", "restart") and p["services"]:
                    for svc in p["services"]:
                        docker_api("POST", f"/containers/{svc['id']}/{act}", timeout=60, raw=True)
                    return self.json({"ok": True, "output": ""})
            except DockerError as e:
                return self.err(502, str(e))
            f = find_compose_file(name, p["config_files"], p["workdir"])
            if not f or not shutil.which("docker"):
                return self.err(400, "compose_cli_unavailable")
            args = {"up": ["up", "-d"], "down": ["down"], "pull": ["pull"], "start": ["up", "-d"], "stop": ["stop"], "restart": ["restart"]}[act]
            try:
                r = subprocess.run(["docker", "compose", "-p", name, "-f", str(f), "--project-directory", str(f.parent)] + args,
                                   capture_output=True, text=True, timeout=900)
            except subprocess.TimeoutExpired:
                return self.err(504, "timeout")
            return self.json({"ok": r.returncode == 0, "output": (r.stdout + r.stderr)[-6000:]})
        if path == "/api/compose/files" and method == "GET":
            if not need_admin():
                return
            return self.json({"dir": str(COMPOSE_DIR), "files": compose_files(), "exists": COMPOSE_DIR.is_dir()})
        if path == "/api/compose/file":
            if not need_admin():
                return
            if method == "GET":
                p = safe_compose_path(q.get("path", ""))
                return self.json({"path": q["path"], "content": p.read_text(errors="replace") if p.is_file() else ""})
            if method == "PUT":
                b = self.body()
                p = safe_compose_path(s(b.get("path"), 300))
                if p.is_file():
                    shutil.copyfile(p, str(p) + ".bak")
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(str(b.get("content", "")))
                return self.json({"ok": True})

        # ---- home assistant
        if path == "/api/ha/states" and method == "GET":
            cfg = get_config()
            ents = cfg["ha"]["entities"]
            if not cfg["ha"]["url"] or not cfg["ha"]["token"]:
                return self.json({"configured": False, "entities": []})
            try:
                states = {x["entity_id"]: x for x in ha_call("GET", "/api/states")}
            except Exception as e:
                return self.json({"configured": True, "error": str(e), "entities": []})
            out = []
            for e in ents:
                st = states.get(e["id"])
                a = (st or {}).get("attributes", {})
                out.append({"id": e["id"], "name": e["name"] or a.get("friendly_name") or e["id"], "state": (st or {}).get("state", "unavailable"),
                            "unit": a.get("unit_of_measurement", ""), "device_class": a.get("device_class", "")})
            return self.json({"configured": True, "entities": out})
        if path == "/api/ha/entities" and method == "GET":
            if not need_admin():
                return
            try:
                return self.json({"entities": [{"id": x["entity_id"], "name": x["attributes"].get("friendly_name", "")} for x in ha_call("GET", "/api/states")]})
            except Exception as e:
                return self.err(502, str(e))
        if path == "/api/ha/test" and method == "POST":
            if not need_admin():
                return
            b = self.body()
            cfg = get_config()
            tok = s(b.get("token"), 2000)
            if tok == "********":
                tok = cfg["ha"]["token"]
            url = s(b.get("url"), 300).rstrip("/")
            if not re.match(r"^https?://", url):
                return self.err(400, "bad_url")
            req = urllib.request.Request(url + "/api/", headers={"Authorization": "Bearer " + tok})
            ctx = None if b.get("verify_tls", True) else ssl._create_unverified_context()
            try:
                with urllib.request.urlopen(req, timeout=6, context=ctx) as r:
                    return self.json({"ok": True, "message": json.loads(r.read()).get("message", "ok")})
            except Exception as e:
                return self.err(502, str(e))
        if path == "/api/ha/service" and method == "POST":
            b = self.body()
            dom, svc, ent = s(b.get("domain"), 40), s(b.get("service"), 40), s(b.get("entity_id"), 100)
            cfg = get_config()
            if (dom, svc) not in HA_ALLOWED or ent.split(".")[0] != dom and dom != "homeassistant" or ent not in [e["id"] for e in cfg["ha"]["entities"]]:
                return self.err(403, "forbidden")
            try:
                ha_call("POST", f"/api/services/{dom}/{svc}", {"entity_id": ent})
            except Exception as e:
                return self.err(502, str(e))
            return self.json({"ok": True})

        # ---- users
        if path == "/api/users":
            if not need_admin():
                return
            if method == "GET":
                return self.json({"users": [{k: u[k] for k in ("username", "role", "language", "created")} for u in users()]})
            if method == "POST":
                b = self.body()
                try:
                    add_user(s(b.get("username"), 40), str(b.get("password", "")), b.get("role", "user"), s(b.get("language"), 5))
                except ValueError as e:
                    return self.err(400, str(e))
                return self.json({"ok": True})
            if method == "PUT":
                b = self.body()
                with LOCK:
                    us = users()
                    t = next((x for x in us if x["username"] == b.get("username")), None)
                    if not t:
                        return self.err(404, "not_found")
                    if "role" in b:
                        new_role = "admin" if b["role"] == "admin" else "user"
                        if t["role"] == "admin" and new_role != "admin" and sum(1 for x in us if x["role"] == "admin") <= 1:
                            return self.err(400, "last_admin")
                        t["role"] = new_role
                    if b.get("password"):
                        if len(b["password"]) < 8:
                            return self.err(400, "password_short")
                        t["password"] = hash_pw(b["password"])
                        t["pv"] = secrets.token_hex(4)
                    save("users.json", us)
                return self.json({"ok": True})
            if method == "DELETE":
                name = q.get("username", "")
                with LOCK:
                    us = users()
                    t = next((x for x in us if x["username"] == name), None)
                    if not t:
                        return self.err(404, "not_found")
                    if t["role"] == "admin" and sum(1 for x in us if x["role"] == "admin") <= 1:
                        return self.err(400, "last_admin")
                    save("users.json", [x for x in us if x is not t])
                return self.json({"ok": True})

        # ---- API tokens
        if path == "/api/tokens":
            if not need_admin():
                return
            toks = load("tokens.json", [])
            if method == "GET":
                return self.json({"tokens": [{"name": t["name"], "created": t["created"]} for t in toks]})
            if method == "POST":
                name = re.sub(r"[^A-Za-z0-9_.-]", "", s(self.body().get("name"), 30))
                if not name or any(t["name"] == name for t in toks):
                    return self.err(400, "invalid_name")
                raw = "hd_" + secrets.token_urlsafe(32)
                toks.append({"name": name, "hash": hashlib.sha256(raw.encode()).hexdigest(), "created": int(time.time())})
                save("tokens.json", toks)
                return self.json({"ok": True, "token": raw})
            if method == "DELETE":
                save("tokens.json", [t for t in toks if t["name"] != q.get("name")])
                return self.json({"ok": True})

        # ---- icons
        if path == "/api/icon" and method == "GET":
            res = None
            if q.get("di"):
                res = get_icon("di", q["di"])
            elif q.get("src") and re.match(r"^https?://", q["src"]):
                res = get_icon("src", q["src"])
            elif q.get("fav") and re.match(r"^https?://", q["fav"]):
                res = get_icon("fav", q["fav"])
            if not res:
                self._headers(404, "text/plain", 0, [("Cache-Control", "max-age=600")])
                return
            data, ct = res
            self._headers(200, ct, len(data), [("Cache-Control", "max-age=86400"), ("Content-Security-Policy", "sandbox")])
            self.wfile.write(data)
            return

        # ---- terminal
        if path.startswith("/api/term/"):
            if not need_admin():
                return
            if not get_config()["terminal"]["enabled"]:
                return self.err(403, "terminal_disabled")
            return self.terminal(method, path, q, user)

        return self.err(404, "not_found")

    def terminal(self, method, path, q, user):
        sid = q.get("id", "")
        if method == "POST":
            b = self.body()
            sid = s(b.get("id"), 64)
        if not re.match(r"^[a-zA-Z0-9-]{8,64}$", sid):
            return self.err(400, "bad_id")
        key = f"{user['username']}:{sid}"
        if path == "/api/term/open" and method == "POST":
            with TERM_LOCK:
                t = TERMS.get(key)
                if not t or (not t.alive and b.get("fresh")):
                    if t:
                        t.close()
                    t = TERMS[key] = Term(user["username"])
                    t.resize(int(b.get("cols", 80)), int(b.get("rows", 24)))
            return self.json({"ok": True})
        t = TERMS.get(key)
        if not t:
            return self.err(404, "no_session")
        if path == "/api/term/input" and method == "POST":
            t.write(base64.b64decode(b.get("data", "")))
            return self.json({"ok": True})
        if path == "/api/term/resize" and method == "POST":
            t.resize(max(10, min(500, int(b.get("cols", 80)))), max(3, min(200, int(b.get("rows", 24)))))
            return self.json({"ok": True})
        if path == "/api/term/close" and method == "POST":
            with TERM_LOCK:
                t.close()
                TERMS.pop(key, None)
            return self.json({"ok": True})
        if path == "/api/term/stream" and method == "GET":
            pos = int(self.headers.get("Last-Event-ID") or q.get("from") or 0)
            self.send_response(200)
            for k, v in {"Content-Type": "text/event-stream", "Cache-Control": "no-cache", "Connection": "close", "X-Accel-Buffering": "no", **SEC_HEADERS}.items():
                self.send_header(k, v)
            self.end_headers()
            self.close_connection = True
            try:
                while True:
                    with t.cond:
                        pos = max(pos, t.base)
                        while pos >= t.base + len(t.buf) and t.alive:
                            if not t.cond.wait(15):
                                break
                        data = bytes(t.buf[pos - t.base:pos - t.base + 32768])
                        alive = t.alive
                    if data:
                        pos += len(data)
                        self.wfile.write(b"id: %d\ndata: %s\n\n" % (pos, base64.b64encode(data)))
                    elif not alive:
                        self.wfile.write(b"event: exit\ndata: 0\n\n")
                        self.wfile.flush()
                        break
                    else:
                        self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
            return
        return self.err(404, "not_found")


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64

    def handle_error(self, request, client_address):
        if isinstance(sys.exc_info()[1], (BrokenPipeError, ConnectionResetError, ConnectionAbortedError)):
            return  # client went away (normal for SSE/terminal streams)
        super().handle_error(request, client_address)


def main():
    global SECRET
    DATA.mkdir(parents=True, exist_ok=True)
    SECRET = get_secret()
    if not users() and os.environ.get("ADMIN_USER") and os.environ.get("ADMIN_PASSWORD"):
        try:
            add_user(os.environ["ADMIN_USER"], os.environ["ADMIN_PASSWORD"], "admin")
            print("Created admin user from environment.")
        except ValueError as e:
            print("Could not create admin from env:", e)
    threading.Thread(target=sampler, daemon=True).start()
    threading.Thread(target=reap_terms, daemon=True).start()
    srv = Server((BIND, PORT), Handler)
    print(f"HomeDash {VERSION} listening on http://{BIND}:{PORT}  (data: {DATA})", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
